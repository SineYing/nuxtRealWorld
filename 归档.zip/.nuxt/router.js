import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _bc48f704 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _50a8799a = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _1e04eb95 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _126faf7c = () => interopDefault(import('../pages/setting' /* webpackChunkName: "" */))
const _d3e6aa7e = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _70696e22 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))
const _ecc1aa56 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _bc48f704,
    children: [{
      path: "",
      component: _50a8799a,
      name: "home"
    }, {
      path: "/login",
      component: _1e04eb95,
      name: "login"
    }, {
      path: "/register",
      component: _1e04eb95,
      name: "register"
    }, {
      path: "/setting",
      component: _126faf7c,
      name: "setting"
    }, {
      path: "/editor",
      component: _d3e6aa7e,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _70696e22,
      name: "article"
    }, {
      path: "/profile/:username",
      component: _ecc1aa56,
      name: "profile"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
